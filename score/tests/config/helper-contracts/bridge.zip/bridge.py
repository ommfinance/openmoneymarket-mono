from .constants import *
from .irc_2_interface import IRC2TokenStandard
from .token_fallback_interface import TokenFallbackInterface
from .qualification_check import *


class Bridge(IconScoreBase, IRC2TokenStandard):

    def __init__(self, db: IconScoreDatabase) -> None:
        super().__init__(db)
        self._total_supply = VarDB('total_supply', db, value_type=int)
        self._decimals = VarDB('decimals', db, value_type=int)
        self._balances = DictDB('balances', db, value_type=int)
        self._whitelist = DictDB('whitelist', db, value_type=int, depth=2)
        self._free_daily_tx_limit = VarDB('free_daily_tx_limit', db, value_type=int)
        self._icx_amount_to_user = VarDB('icx_amount_to_user', db, value_type=int)
        self._pending_withdrawal_requests_count = VarDB('pending_withdrawal_requests_count', db, value_type=int)
        self._score_owner = VarDB('score_owner', db, value_type=Address)
        self._freezing_wallet = VarDB('freezing_wallet', db, value_type=Address)
        self._frozen_wallets = DictDB('frozen_wallets', db, value_type=bool)

    def on_install(self, _decimals: int = 18) -> None:
        super().on_install()

        if _decimals < 0:
            revert("Decimals cannot be less than zero")

        self._total_supply.set(0)
        self._decimals.set(_decimals)
        self._free_daily_tx_limit.set(50)
        self._icx_amount_to_user.set(2 * 10 ** 17)
        self._pending_withdrawal_requests_count.set(0)
        self._score_owner.set(self.msg.sender)

    def on_update(self) -> None:
        super().on_update()
        #self.burn_inconsistent_USDb()

    # def burn_inconsistent_USDb(self):
    #     """
    #     This updates burns the USDb which has been decreased from the user's balance but not from the total supply.
    #     """
    #     # Amount to decrease in mainnet hardcoded
    #     inconsistent_amount = 10000000000000000000
    #     self._total_supply.set(self._total_supply.get() - inconsistent_amount)
    #     self.Transfer(self.address, ZERO_WALLET_ADDRESS, inconsistent_amount, b'Burned the inconsistent USDb')

    @external(readonly=True)
    def name(self) -> str:
        return "Bridge"

    @external(readonly=True)
    def symbol(self) -> str:
        return "USDb"

    @external(readonly=True)
    def decimals(self) -> int:
        return self._decimals.get()

    @external(readonly=True)
    def totalSupply(self) -> int:
        return self._total_supply.get()

    @external(readonly=True)
    def scoreOwner(self) -> Address:
        return self._score_owner.get()

    @external(readonly=True)
    def freeDailyTxLimit(self) -> int:
        return self._free_daily_tx_limit.get()

    @external(readonly=True)
    def ICXAmountToUser(self) -> int:
        return self._icx_amount_to_user.get()

    @external(readonly=True)
    def freezingWallet(self) -> Address:
        return self._freezing_wallet.get()

    @external(readonly=True)
    def pendingWithdrawalRequestsCount(self) -> int:
        return self._pending_withdrawal_requests_count.get()

    @external(readonly=True)
    def balanceOf(self, _owner: Address) -> int:
        return self._balances[_owner]

    @external(readonly=True)
    def isFrozen(self, _owner: Address) -> bool:
        return self._frozen_wallets[_owner]

    @external(readonly=True)
    def isWhitelisted(self, _owner: Address) -> bool:
        return not self._whitelist[_owner]['free_tx_start_height'] == 0

    @external(readonly=True)
    def withdrawalRequest(self, _request_id: int) -> dict:
        _from_db = VarDB('withdrawal_request_' + str(_request_id) + "_address", self.db, value_type=Address)
        _value_db = VarDB('withdrawal_request_' + str(_request_id) + "_value", self.db, value_type=int)

        if _request_id >= self._pending_withdrawal_requests_count.get() or _from_db.get() is None:
            revert("Stably USD: request ID does not exist")

        return {"_from": _from_db.get(), "value": _value_db.get()}

    @external(readonly=True)
    def remainingFreeTxThisTerm(self, _owner: Address) -> int:
        if self._whitelist[_owner]['free_tx_start_height']:
            if self._whitelist[_owner]['free_tx_start_height'] + TERM_LENGTH < self.block_height:
                return self._free_daily_tx_limit.get()
            else:
                return self._free_daily_tx_limit.get() - self._whitelist[_owner]['free_tx_count_since_start']
        return 0

    @only_score_owner
    @external
    def changeScoreOwner(self, _new_score_owner: Address, _data: bytes = None):
        if _data is None:
            _data = b'None'

        self._score_owner.set(_new_score_owner)
        self.ScoreOwnerChanged(self.msg.sender, _new_score_owner, _data)
        Logger.debug(f'Owner Changed({self.msg.sender}, {_new_score_owner}, {_data})', TAG)

    @only_score_owner
    @external
    def changeFreeDailyTxLimit(self, _new_limit: int):
        if _new_limit < 0:
            revert("Stably USD: Free daily TX limit cannot be below 0")

        old_limit = self._free_daily_tx_limit.get()
        self._free_daily_tx_limit.set(_new_limit)
        self.FreeDailyTxLimitChanged(old_limit, _new_limit)
        Logger.debug(f'Free Daily TX Limit Changed({old_limit}, {_new_limit})', TAG)

    @only_score_owner
    @external
    def changeICXAmountToUser(self, _new_amount: int):
        if _new_amount < 0:
            revert("Stably USD: ICX Amount send to users cannot be below 0")

        old_amount = self._icx_amount_to_user.get()
        self._icx_amount_to_user.set(_new_amount)
        self.ICXAmountToUserChanged(old_amount, _new_amount)
        Logger.debug(f'ICX Amount to User Changed({old_amount}, {_new_amount})', TAG)

    @external
    def changeFreezingWallet(self, _new_wallet: Address, _data: bytes = None):
        if self.msg.sender != self._freezing_wallet.get() and self.msg.sender != self._score_owner.get():
            revert("Stably USD: only score owner and freezing wallet can change the freezing wallet")
        self.set_fee_sharing_proportion(100)
        if _data is None:
            _data = b'None'

        old_wallet = self._freezing_wallet.get()
        self._freezing_wallet.set(_new_wallet)
        self.FreezingWalletChanged(old_wallet, _new_wallet, _data)
        Logger.debug(f'Freezing Wallet Changed({self.msg.sender}, {_new_wallet}, {_data})', TAG)

    @external
    def freezeWallet(self, _owner: Address, _data: bytes = None):
        if self.msg.sender != self._freezing_wallet.get():
            revert("Stably USD: only freezing wallet can freeze")
        self.set_fee_sharing_proportion(100)
        if _data is None:
            _data = b'None'

        self._frozen_wallets[_owner] = True

        self.WalletFrozen(_owner, _data)
        Logger.debug(f'Wallet got frozen({_owner}, {_data})', TAG)

    @external
    def unfreezeWallet(self, _owner: Address, _data: bytes = None):
        if self.msg.sender != self._freezing_wallet.get():
            revert("Stably USD: only freezing wallet can unfreeze")
        self.set_fee_sharing_proportion(100)
        if _data is None:
            _data = b'None'

        self._frozen_wallets[_owner] = False

        self.WalletUnfrozen(_owner, _data)
        Logger.debug(f'Wallet got unfrozen({_owner}, {_data})', TAG)

    @set_fee_sharing_percentage
    @external
    def transfer(self, _to: Address, _value: int, _data: bytes = None):
        if _data is None:
            _data = b'None'
        self._transfer(self.msg.sender, _to, _value, _data)

    @only_score_owner
    @external
    def whitelistWallet(self, _to: Address, _data: bytes = None):
        if _data is None:
            _data = b'None'

        self._whitelistWallet(_to, _data)

    @only_score_owner
    @external
    def mint(self, _to: Address, _value: int, _data: bytes = None):
        if _data is None:
            _data = b'None'

        self._mint(_to, _value, _data)

    @set_fee_sharing_percentage
    @external
    def createWithdrawalRequest(self, _value: int, _data: bytes = None) -> int:
        if _data is None:
            _data = b'None'
        return self._createWithdrawalRequest(self.msg.sender, _value, _data)

    @only_score_owner
    @external
    def acceptWithdrawalRequest(self, _request_id: int, _data: bytes = None):
        if _data is None:
            _data = b'None'

        self._acceptWithdrawalRequest(_request_id, _data)

    @only_score_owner
    @external
    def rejectWithdrawalRequest(self, _request_id: int, _data: bytes = None):
        if _data is None:
            _data = b'None'

        self._rejectWithdrawalRequest(_request_id, _data)

    @only_score_owner
    @payable
    def fallback(self):
        self.ReceivedICX(self.msg.sender, self.msg.value)
        Logger.debug(f'ReceivedICX({self.msg.sender}, {self.msg.value})', TAG)

    def _transfer(self, _from: Address, _to: Address, _value: int, _data: bytes):
        if self._frozen_wallets[self.msg.sender]:
            revert("Stably USD: Wallet is frozen and cannot transfer USDS")
        if _value < 0:
            revert("Stably USD: Transferring value cannot be less than zero")
        if self._balances[_from] < _value:
            revert("Stably USD: Out of balance")
        if _to == ZERO_WALLET_ADDRESS:
            revert("Stably USD: Can not transfer Bridge to zero wallet address.")

        self._balances[_from] = self._balances[_from] - _value
        self._balances[_to] = self._balances[_to] + _value
        if _to.is_contract:
            recipient_score = self.create_interface_score(_to, TokenFallbackInterface)
            recipient_score.tokenFallback(_from, _value, _data)

        self.Transfer(_from, _to, _value, _data)
        Logger.debug(f'Transfer({_from}, {_to}, {_value}, {_data})', TAG)

    def _whitelistWallet(self, _to: Address, _data: bytes):
        if _to == ZERO_WALLET_ADDRESS:
            revert("Stably USD: Can not whitelist zero wallet address")

        if not self._whitelist[_to]['free_tx_start_height']:
            self._whitelist[_to]['free_tx_start_height'] = self.block_height
            self._whitelist[_to]['free_tx_count_since_start'] = 1
            self.icx.send(_to, self._icx_amount_to_user.get())

            self.WhitelistWallet(_to, _data)
            Logger.debug(f'WhitelistWallet({_to}, {_data})', TAG)

    def _mint(self, _to: Address, _value: int, _data: bytes):
        if self._frozen_wallets[_to]:
            revert("Stably USD: Wallet is frozen and cannot receive USDS")
        if _value < 0:
            revert("Stably USD: Transferring value cannot be less than zero")

        self._whitelistWallet(_to, _data)

        self._total_supply.set(self._total_supply.get() + _value)
        self._balances[_to] = self._balances[_to] + _value
        self.Transfer(ZERO_WALLET_ADDRESS, _to, _value, b'Minted new tokens')

        self.Mint(_to, _value, _data)
        Logger.debug(f'Mint({_to}, {_value}, {_data})', TAG)

    def _createWithdrawalRequest(self, _from: Address, _value: int, _data: bytes) -> int:
        if self._frozen_wallets[self.msg.sender]:
            revert("Stably USD: Wallet is frozen and cannot execute TXs")
        if _value <= 0:
            revert("Stably USD: Withdrawing value cannot be less than zero")
        if self._balances[_from] < _value:
            revert("Stably USD: Out of balance")

        _request_id = self._pending_withdrawal_requests_count.get()

        VarDB('withdrawal_request_' + str(_request_id) + "_address", self.db, value_type=Address).set(_from)
        VarDB('withdrawal_request_' + str(_request_id) + "_value", self.db, value_type=int).set(_value)

        self._pending_withdrawal_requests_count.set(_request_id + 1)

        self._total_supply.set(self._total_supply.get() - _value)
        self._balances[_from] = self._balances[_from] - _value
        self.Transfer(_from, ZERO_WALLET_ADDRESS, _value, b'Burned tokens for withdrawal')
        self.Burn(_from, _value, f"Burned {_value/10**self.decimals()} {self.symbol()} tokens from {_from}")

        self.WithdrawalRequestCreated(_request_id, _from, _value, _data)
        Logger.debug(f'WithdrawalRequestCreated({_request_id}, {_from}, {_value}, {_data})', TAG)
        return _request_id

    def _acceptWithdrawalRequest(self, _request_id: int, _data: bytes):
        _from_db = VarDB('withdrawal_request_' + str(_request_id) + "_address", self.db, value_type=Address)
        _value_db = VarDB('withdrawal_request_' + str(_request_id) + "_value", self.db, value_type=int)

        if _request_id >= self._pending_withdrawal_requests_count.get() or _from_db.get() is None:
            revert("Stably USD: request ID does not exist")

        if self._frozen_wallets[_from_db.get()]:
            revert("Stably USD: Wallet is frozen and cannot withdraw")

        self.WithdrawalRequestAccepted(_from_db.get(), _value_db.get(), _data)
        Logger.debug(f'WithdrawalRequestAccepted({_from_db.get()}, {_value_db.get()}, {_data})', TAG)

        _from_db.remove()
        _value_db.remove()

    def _rejectWithdrawalRequest(self, _request_id: int, _data: bytes):
        _from_db = VarDB('withdrawal_request_' + str(_request_id) + "_address", self.db, value_type=Address)
        _value_db = VarDB('withdrawal_request_' + str(_request_id) + "_value", self.db, value_type=int)

        if _request_id >= self._pending_withdrawal_requests_count.get() or _from_db.get() is None:
            revert("Stably USD: request ID does not exist")

        self._balances[_from_db.get()] = self._balances[_from_db.get()] + _value_db.get()
        self._total_supply.set(self._total_supply.get() + _value_db.get())
        self.Transfer(ZERO_WALLET_ADDRESS, _from_db.get(), _value_db.get(), b'Minted new tokens for rejecting '
                                                                            b'withdrawal request')
        self.Mint(_from_db.get(), _value_db.get(), b'Minted new tokens for rejecting withdrawal request')

        self.WithdrawalRequestRejected(_from_db.get(), _value_db.get(), _data)
        Logger.debug(f'WithdrawalRequestRejected({_from_db.get()}, {_value_db.get()}, {_data})', TAG)

        _from_db.remove()
        _value_db.remove()

    @eventlog(indexed=3)
    def ScoreOwnerChanged(self, _old_score_owner: Address, _new_score_owner: Address, _data: bytes):
        pass

    @eventlog(indexed=3)
    def FreezingWalletChanged(self, _old_wallet: Address, _new_wallet: Address, _data: bytes):
        pass

    @eventlog(indexed=2)
    def WalletFrozen(self, _owner: Address, _data: bytes):
        pass

    @eventlog(indexed=2)
    def WalletUnfrozen(self, _owner: Address, _data: bytes):
        pass

    @eventlog(indexed=2)
    def FreeDailyTxLimitChanged(self, _old_limit: int, _new_limit: int):
        pass

    @eventlog(indexed=2)
    def ICXAmountToUserChanged(self, _old_amount: int, _new_amount: int):
        pass

    @eventlog(indexed=3)
    def Transfer(self, _from: Address, _to: Address, _value: int, _data: bytes):
        pass

    @eventlog(indexed=2)
    def WhitelistWallet(self, _to: Address, _data: bytes):
        pass

    @eventlog(indexed=3)
    def Mint(self, _to: Address, _value: int, _data: bytes):
        pass

    @eventlog(indexed=3)
    def WithdrawalRequestCreated(self, _request_id: int, _from: Address, _value: int, _data: bytes):
        pass

    @eventlog(indexed=3)
    def WithdrawalRequestCanceled(self, _from: Address, _value: int, _data: bytes):
        pass

    @eventlog(indexed=3)
    def WithdrawalRequestAccepted(self, _from: Address, _value: int, _data: bytes):
        pass

    @eventlog(indexed=3)
    def WithdrawalRequestRejected(self, _from: Address, _value: int, _data: bytes):
        pass

    @eventlog(indexed=2)
    def ReceivedICX(self, _from: Address, _value: int):
        pass

    @eventlog(indexed=1)
    def Burn(self, _from: Address, _value: int, _data: str):
        pass
