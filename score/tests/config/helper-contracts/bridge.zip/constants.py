from iconservice import *

# ================================================
#  Consts
# ================================================
TAG = 'Stably USD'
ZERO_SCORE_ADDRESS = Address.from_string('cx0000000000000000000000000000000000000000')
ZERO_WALLET_ADDRESS = Address.from_string('hx0000000000000000000000000000000000000000')
TERM_LENGTH = 43120