from iconservice import *
from .constants import *


def only_score_owner(func):
    if not isfunction(func):
        revert(f"{func} is not a function.")

    @wraps(func)
    def __wrapper(self: object, *args, **kwargs):
        if self.msg.sender != self._score_owner.get():
            revert(f"Stably USD: {func} method can be called only by the SCORE owner")
        self.set_fee_sharing_proportion(100)
        return func(self, *args, **kwargs)
    return __wrapper


def set_fee_sharing_percentage(func):
    if not isfunction(func):
        revert(f"{func} is not a function.")

    @wraps(func)
    def __wrapper(self: object, *args, **kwargs):
        if self._whitelist[self.msg.sender]['free_tx_start_height']:
            if self._whitelist[self.msg.sender]['free_tx_start_height'] + TERM_LENGTH < self.block_height:
                self._whitelist[self.msg.sender]['free_tx_start_height'] = self.block_height
                self._whitelist[self.msg.sender]['free_tx_count_since_start'] = 1
                self.set_fee_sharing_proportion(100)
            elif self._whitelist[self.msg.sender]['free_tx_count_since_start'] <= self._free_daily_tx_limit.get():
                self._whitelist[self.msg.sender]['free_tx_count_since_start'] = \
                    self._whitelist[self.msg.sender]['free_tx_count_since_start'] + 1
                self.set_fee_sharing_proportion(100)

        return func(self, *args, **kwargs)
    return __wrapper
