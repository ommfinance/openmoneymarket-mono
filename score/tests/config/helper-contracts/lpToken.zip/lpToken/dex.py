from iconservice import *
TAG = 'DUMMY DEX'

EOA_ZERO = Address.from_string('hx0000000000000000000000000000000000000000')

class TokenFallbackInterface(InterfaceScore):
    @interface
    def onIRC31Received(self, _operator: Address, _from:Address, _id:int, _value:int, _data:bytes) -> None:
        pass


class DEX(IconScoreBase):

    # System
    def __init__(self, db: IconScoreDatabase) -> None:
        super().__init__(db)
        self._balance = DictDB('balances', db, value_type=int, depth=2)

    # def on_install(self, _governance: Address) -> None:
    def on_install(self) -> None:
        super().on_install()

    def on_update(self) -> None:
        super().on_update()

    @external(readonly=True)
    def name(self) -> str:
        return TAG

    @external
    def mint(self, _to: Address, _id: int) -> None:
        self._balance[_id][_to] = 1000 * 10 ** 18

    @external
    def transfer(self, _to: Address, _value: int, _id: int, _data: bytes = None):
        if _data is None:
            _data = b'None'
        self._transfer(self.msg.sender, _to, _value, _id, _data)

    def _transfer(self, _from: Address, _to: Address, _value: int, _id: int, _data: bytes):
        self._balance[_id][_from] -= _value
        self._balance[_id][_to] += _value
        if _to.is_contract:
            recipient_score = self.create_interface_score(_to, TokenFallbackInterface)
            recipient_score.onIRC31Received(EOA_ZERO, _from, _id, _value, _data)

    @external(readonly=True)
    def balanceOf(self, _owner: Address, _id: int) -> int:
        return self._balance[_id][_owner]

    @external(readonly=True)
    def getPoolStats(self, _id: int) -> dict:
        stats = {
          "base_decimals": 18,
          "quote_decimals": 18,
          "id": _id
        }
        return stats