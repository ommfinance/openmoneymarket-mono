from .sicx import StakedICX
